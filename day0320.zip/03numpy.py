import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

my_list = list(range(100000)) #my_list = list(range(1_000_000))
print(my_list)


# my_list = np.arange(1000) #my_list = list(range(1_000_000))
# print(my_list)








print()
print()